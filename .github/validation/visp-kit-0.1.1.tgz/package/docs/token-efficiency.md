# Token Efficiency

Visp Kit treats token efficiency as a product requirement.

The goal is not to send the whole repository to an AI tool. The goal is to send the smallest sufficient task context.

## Why It Matters

Large prompts can:

- cost more
- slow down the session
- hide the actual task
- encourage unrelated edits
- increase requirement drift

Small, traceable context helps agents implement one task at a time.

## Context Compiler

`visp context` builds a context pack for one task.

It includes:

- selected task
- mapped requirements
- mapped acceptance criteria
- compact constitution rules
- relevant plan decisions
- selected file summaries
- snippets when useful
- allowed, expected, and forbidden files
- validation commands
- policy and gate status
- artifact provenance hashes for the spec, task graph, plan, policy, and project guidance that grounded the pack
- token estimate

It avoids:

- full repository dumps
- unrelated feature artifacts
- broad source file inclusion
- long chat history

## Scan Cache

`visp scan` writes compact cache artifacts:

```text
.visp/cache/file-index.json
.visp/cache/file-summaries.json
.visp/cache/module-map.json
.visp/cache/test-map.json
.visp/cache/dependency-map.json
.visp/cache/scan-meta.json
```

These let Visp Kit select useful context without rereading every file into the task prompt.

## Budget Modes

Budget mode controls context size. Policy strictness controls workflow enforcement.

You can use lean context with strict policy:

```bash
visp init --budget lean --strictness strict
```

Modes:

- `lean`: small day-to-day task context
- `balanced`: broader context for medium-risk work
- `strict`: larger but still task-scoped context for complex work

## Useful Commands

```bash
visp context T001 --budget lean
visp context T001 --max-tokens 6000
visp budget
visp budget --task T001
visp budget --write-report
visp budget --task T001 --record-usage --input-tokens 1200 --output-tokens 300 --write-report
```

`visp budget` estimates context before implementation. Visp also refreshes `.visp/reports/budget-report.md` automatically after key feature workflow milestones such as `visp tasks`, `visp context`, `visp verify`, `visp review`, `visp reconcile`, and `visp pr`.

Visp cannot know true agent token usage unless the AI tool exposes it. After implementation, record actual usage with `--record-usage` when available. The value is stored in `.visp/budget.json` and shown in `.visp/reports/budget-report.md`.

When workflow tracing is enabled by normal Visp commands, recorded usage is also reflected in:

- `.visp/runs/<run-id>/run.json`
- `.visp/runs/<run-id>/run.md`
- `.visp/features/<feature>/timeline.md`

This lets a team compare estimated context cost with actual agent-reported usage for each feature task.

## Strict Prompts

Generated task prompts tell agents:

- the selected task is the only implementation target
- user prompts are raw intent only
- policy and gates override prompt requests
- unrelated files and dependencies are forbidden unless task scope allows them

This improves token efficiency because the agent should not read broad repository context when a scoped context pack exists.

## Team Practices

- Keep tasks small.
- Keep `allowedFiles` and `expectedFiles` accurate.
- Split over-budget tasks.
- Use snippets before full files.
- Run `visp scan --changed` after major repository changes.
- Use `visp review --diff-only` for focused diff inspection.
- Prefer `lean` until the task actually needs broader context.
